public class Phone {
public String brand;
public String color;
public int price;
public boolean used;

public Phone (String brand, String color, int price, boolean used) {
this.brand = brand;
this.color = color;
this.price = price;
this.used = true;
}

}